mystring = "this is a string"
print(mystring)
print(type(mystring))
print(mystring + " is of the data type " + str(type(mystring)))
firststring = "water"
secondstring = "fall"
thirdstring = firststring+secondstring
print(thirdstring)
name = input("what is your name")
print("hello " + name)
colour = input("what is your favorite colour")
animal = input("what is your favorite animal")
print("{}, you like a {} {} !".format(name,color,animal))